<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "amusement_park";

// การเชื่อมต่อฐานข้อมูล
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["email_or_username"]) && isset($_POST["password"])) {
    // รับค่า login input ที่อาจจะเป็น email หรือ username
    $login_input = $_POST["email_or_username"];
    $password = $_POST["password"];

    // เตรียมคำสั่ง SQL สำหรับตรวจสอบข้อมูลจากฐานข้อมูล
    $stmt = $conn->prepare("SELECT id, username, password, role FROM users1 WHERE email = ? OR username = ?");
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }
    $stmt->bind_param("ss", $login_input, $login_input); // bind ค่า
    $stmt->execute();

    $result = $stmt->get_result();

    // ถ้าพบข้อมูล
    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();

        // ตรวจสอบรหัสผ่าน
        if (password_verify($password, $row["password"])) {
            // ถ้ารหัสผ่านถูกต้อง ให้บันทึกข้อมูลลงใน session
            $_SESSION["user_id"] = $row["id"];
            $_SESSION["user_role"] = $row["role"];
            $_SESSION["user_username"] = $row["username"]; // เพิ่มบรรทัดนี้เพื่อเก็บ username

            // ส่งผู้ใช้ไปยังหน้า index
            header("Location: index.php");
            exit();
        } else {
            // รหัสผ่านไม่ถูกต้อง
            echo "❌ อีเมล/ชื่อผู้ใช้ หรือรหัสผ่านไม่ถูกต้อง!";
        }
    } else {
        // ไม่พบผู้ใช้ในระบบ
        echo "❌ ไม่พบผู้ใช้ในระบบ!";
    }

    // ปิดการเชื่อมต่อฐานข้อมูล
    $stmt->close();
    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script src="script.js" defer></script>
    <title>Log In</title>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@400;700&family=Henny+Penny&family=Pixelify+Sans:wght@400..700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>

<body>
    <header>
        <div class="logo">
            <img src="https://i.ibb.co/W49PVTYr/411-20250404174508.png" alt="Fun Spot">
        </div>
        <nav>
            <ul>
                <li><a href="reservation.php" class="button">Reservation</a></li>
                <li><a href="index.php" class="cc">Home</a></li>
                <li><a href="rides.php" class="cc">Rides</a></li>
                <li><a href="about.php" class="cc">About</a></li>
                <li><a href="login.php" class="cc" style="background-color: #FE654F;">Login</a></li>
            </ul>
        </nav>
    </header>
    <section class="farea">
        <div class="glass">
            <h2 style="font-size: 70px; text-shadow: -1px -1px 0 black, 5px -1px 0 black, -1px 5px 0 black, 1px 1px 0 black;">LOG IN</h2>
            <br>
            <form action="login.php" method="POST">
                <input type="text" name="email_or_username" placeholder="Email or Username" required><br>
                <input type="password" id="password" name="password" placeholder="Password" required><br><br>
                <div class="bb" id="custom-submit">
                    <div class="bb1"><span>Go to DOKi BOOKi</span></div>
                </div>
                <input type="submit" id="real-submit" value="Go to DOKi BOOKi" style="display: none;">
            </form>
            <br>
            <p>No Account? <a href="register.php">Registration</a></p>
        </div>
    </section>

    <footer class="footer">
        <br>
        <img src="https://i.ibb.co/W49PVTYr/411-20250404174508.png" alt="Adventure Coast Logo">
        <p>Linggang guli guli guli wangja, ling ganggu, ling ganggu, TH</p>
        <br><br>
        <div class="social-icons">
            <a href="https://facebook.com" target="_blank"><i class="fa-brands fa-facebook-f"></i></a>
            <a href="https://tiktok.com" target="_blank"><i class="fa-brands fa-tiktok"></i></a>
            <a href="https://instagram.com" target="_blank"><i class="fa-brands fa-instagram"></i></a>
            <a href="mailto:someone@example.com"><i class="fa-solid fa-envelope"></i></a>
        </div>
        <br>
        <div class="links">
            <a href="#">FAQs</a>
            <a href="#">Careers</a>
            <a href="#">Contact Us</a>
            <a href="#">Terms & Conditions</a>
            <a href="#">Privacy Policy & Cookies</a>
        </div>
        <p class="copyright" style="color: yellow; font-weight: bold;">© 2025 DOKi BOOKi.</p>
    </footer>

    <div class="admin-wrapper">
        <div class="admin" id="adminButton">
            <input type="checkbox" id="adminCheckbox" hidden />
            <span></span>
            <span></span>
            <span></span>
            <span></span>
        </div>
        <div id="chat-box" class="chat-box">
            <div class="chat-header">
                <span>Admin</span>
            </div>
            <div class="chat-messages" id="chat-messages">
                <!-- ข้อความแชทจะมาที่นี่ -->
            </div>
            <input type="text" id="chat-input" class="chat-input" placeholder="text here!">
            <button id="send-message" class="send-message">send</button>
        </div>
    </div>
</body>

</html>