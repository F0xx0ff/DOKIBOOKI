document.addEventListener("DOMContentLoaded", function () {
    // ตัวอย่างฟังก์ชัน JavaScript ที่จะทำงานเมื่อโหลดหน้าจอ
    const heroSection = document.querySelector('.hero');
    heroSection.addEventListener('mouseover', function () {
        heroSection.style.backgroundColor = '#ff80ab';
    });

    heroSection.addEventListener('mouseout', function () {
        heroSection.style.backgroundColor = 'transparent';
    });
});



// เปิดและปิดแชท
const adminButton = document.getElementById('adminButton');
const adminWindow = document.getElementById('chat-box');

let isOpen = false;

adminButton.addEventListener('click', () => {
    isOpen = !isOpen;
    adminWindow.style.display = isOpen ? 'flex' : 'none';
});


document.getElementById('send-message').addEventListener('click', function () {
    var message = document.getElementById('chat-input').value;
    if (message.trim() !== "") {
        // สร้าง container สำหรับข้อความ + เวลา
        var messageContainer = document.createElement('div');
        messageContainer.classList.add('chat-message');

        // ข้อความ
        var messageElement = document.createElement('div');
        messageElement.textContent = message;
        messageContainer.appendChild(messageElement);

        // เวลาปัจจุบัน
        var now = new Date();
        var hours = now.getHours().toString().padStart(2, '0');
        var minutes = now.getMinutes().toString().padStart(2, '0');
        var time = `${hours}:${minutes}`;

        // สร้าง element เวลา
        var timeElement = document.createElement('span');
        timeElement.textContent = time;
        timeElement.classList.add('chat-time');
        messageContainer.appendChild(timeElement);

        // เพิ่มเข้าในกล่องแชท
        document.getElementById('chat-messages').appendChild(messageContainer);

        // ล้างช่อง input
        document.getElementById('chat-input').value = '';

        // Scroll ลงล่างอัตโนมัติ
        document.getElementById('chat-messages').scrollTop = document.getElementById('chat-messages').scrollHeight;
    }
});


// ใช้ Enter ในการส่งข้อความ
document.getElementById('chat-input').addEventListener('keypress', function (event) {
    if (event.key === 'Enter') {
        document.getElementById('send-message').click();
    }
});



document.addEventListener("DOMContentLoaded", function () {
    const calendarBtn = document.getElementById("calendarBtn");
    const calendarContainer = document.getElementById("calendarContainer");
    const datePicker = document.getElementById("datePicker");
    const dateInput = document.getElementById("dateInput");

    // กำหนดวันเริ่มต้นและวันสูงสุด (วันนี้ - อีก 4 เดือน)
    let today = new Date();
    let maxDate = new Date();
    maxDate.setMonth(today.getMonth() + 4);

    datePicker.min = today.toISOString().split("T")[0];
    datePicker.max = maxDate.toISOString().split("T")[0];

    // เปิด-ปิด ปฏิทิน
    calendarBtn.addEventListener("click", function () {
        calendarContainer.classList.toggle("hidden");
    });

    // อัปเดตค่าหลังเลือกวันที่
    datePicker.addEventListener("change", function () {
        dateInput.value = datePicker.value;
        calendarContainer.classList.add("hidden");
    });

    // เมื่อกดปุ่ม Confirm ให้ไปหน้าขอบคุณ
    document.getElementById("reservationForm").addEventListener("submit", function (event) {
        event.preventDefault();
        window.location.href = "thankyou.html";
    });
});

document.getElementById('custom-submit').addEventListener('click', function () {
    document.getElementById('real-submit').click();
});

document.getElementById("dropdown-btn").addEventListener("click", function(event) {
    console.log("Dropdown button clicked"); // ลองตรวจสอบว่าได้คลิกปุ่มหรือไม่
    var dropdownContent = document.querySelector(".dropdown-content");
    dropdownContent.style.display = (dropdownContent.style.display === "block") ? "none" : "block";
    event.stopPropagation();
});

window.addEventListener("click", function(event) {
    var dropdownContent = document.querySelector(".dropdown-content");
    if (!event.target.matches('#dropdown-btn')) {
        dropdownContent.style.display = "none";
    }
});
