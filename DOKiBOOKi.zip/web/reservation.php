<?php
session_start();

// ดึงข้อมูลราคาตั๋วจาก DB
$conn = new mysqli("localhost", "root", "", "amusement_park");
$tickets = [];
$result = $conn->query("SELECT id, ticket_type, price FROM tickets");
while ($row = $result->fetch_assoc()) {
    $tickets[] = $row;
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style1.css">
    <script src="script.js" defer></script>
    <title>Reservation</title>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@400;700&family=Henny+Penny&family=Pixelify+Sans:wght@400..700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>

<body>
    <header>
        <div class="logo">
            <img src="https://i.ibb.co/W49PVTYr/411-20250404174508.png" alt="Fun Spot">
        </div>
        <nav>
            <ul>
                <li><a href="reservation.php" class="button" style="background-color: #FE654F;">Reservation</a></li>
                <li><a href="index.php" class="cc">Home</a></li>
                <li><a href="rides.php" class="cc">Rides</a></li>
                <li><a href="about.php" class="cc">About</a></li>
                <?php if (isset($_SESSION["user_id"])): ?>
                    <li class="dropdown">
                        <a href="#" class="cc" id="dropdown-btn" style="background-color:rgb(224, 160, 254);"><?= htmlspecialchars($_SESSION["user_username"]) ?></a>
                        <div class="dropdown-content">
                            <a href="profile.php">Profile</a>
                            <a href="logout.php">Logout</a>
                        </div>
                    </li>
                <?php else: ?>
                    <li><a href="login.php" class="cc">Login</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>
    <section class="farea">
        <div class="glass">
            <h2 style="font-size: 70px; text-shadow: -1px -1px 0 black, 5px -1px 0 black, -1px 5px 0 black, 1px 1px 0 black;">Reservation Form</h2>
            <br><br>
            <!-- เพิ่มช่องแสดงชื่อผู้ใช้ที่ล็อกอินแล้ว -->
            <?php if (isset($_SESSION["user_username"])): ?>
                <label style="color: black;">username</label><br>
                <input type="text" name="username" value="<?= htmlspecialchars($_SESSION["user_username"]) ?>" readonly>
            <?php endif; ?>
            <form action="process_booking.php" method="POST" id="bookingForm">
                <div id="persons">
                    <div class="person-block">
                        <?php if (isset($_SESSION["user_username"])): ?>
                            <input type="hidden" name="username" value="<?= htmlspecialchars($_SESSION["user_username"]) ?>">
                        <?php endif; ?>
                        <input type="text" name="firstname[]" placeholder="First Name" required>
                        <input type="text" name="lastname[]" placeholder="Last Name" required><br>
                        <input type="text" name="passport_id" placeholder="Passport ID" require>
                        <br>
                        <div class="ticket-buttons">
                            <?php foreach ($tickets as $ticket): ?>
                                <input type="radio" class="btn-check" name="ticket_id_0" value="<?= $ticket['id'] ?>" data-price="<?= $ticket['price'] ?>" id="ticket<?= $ticket['id'] ?>" autocomplete="off" required>
                                <label class="btn" for="ticket<?= $ticket['id'] ?>">
                                    <?= $ticket['ticket_type'] ?> - <?= $ticket['price'] ?> $
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <br>
                </div>

                <br>
                <button type="button" onclick="addPerson()" class="add">+ Add more person</button><br><br>

                <label style="font-size: 17px; color: black;">DATE</label><br>
                <input type="date" name="booking_date" style="font-family: 'Bai Jamjuree';" required><br><br>
                <input type="hidden" name="quantity" id="quantity" style="font-family: 'Bai Jamjuree';">
                <input type="hidden" name="total_price" id="total_price" style="font-family: 'Bai Jamjuree';">

                <p>Total Ticket: <span id="totalTickets" style="font-family: 'Bai Jamjuree';">1</span></p>
                <p>Total Price: <span id="totalPrice" style="font-family: 'Bai Jamjuree';">0</span> $</p>
                <br>
                <button class="comfirm" type="submit">
                    <div><span>Comfirm</span></div>
                </button>
            </form>
        </div>
    </section>

    <script>
        let personCount = 1;
        const tickets = <?= json_encode($tickets) ?>;

        function addPerson() {
            const container = document.getElementById('persons');
            const block = document.createElement('div');
            block.classList.add('person-block');
            block.style.marginBottom = "20px";

            let html = `
        <button type="button" onclick="removePerson(this)" style="float:right; background:white; color:white; border:none; border-radius: 4px;">❌</button><br>
        <input type="text" name="firstname[]" placeholder="First Name" required>
        <input type="text" name="lastname[]" placeholder="Last Name" required><br>
        <input type="text" name="passport_id" placeholder="Passport ID" require><br>
        <div class="ticket-buttons">
    `;

            tickets.forEach(t => {
                const radioId = `ticket_${t.id}_${personCount}`;
                html += `
            <input type="radio" class="btn-check" name="ticket_id_${personCount}" value="${t.id}" data-price="${t.price}" id="${radioId}" autocomplete="off" required>
            <label class="btn" for="${radioId}">
                ${t.ticket_type} - ${t.price} บาท
            </label>
        `;
            });

            html += `</div>`;
            block.innerHTML = html;
            container.appendChild(block);
            personCount++;
            updateTotals();
        }


        function removePerson(button) {
            const container = document.getElementById('persons');
            if (container.children.length <= 1) {
                alert("ต้องมีผู้เข้าร่วมอย่างน้อย 1 คน");
                return;
            }

            const block = button.parentElement;
            block.remove();
            updateTotals();
        }

        document.getElementById('bookingForm').addEventListener('change', updateTotals);
        document.getElementById('bookingForm').addEventListener('input', updateTotals);

        function updateTotals() {
            let total = 0;
            const prices = document.querySelectorAll('input[type="radio"]:checked');
            prices.forEach(p => {
                total += parseInt(p.dataset.price);
            });

            document.getElementById('totalTickets').textContent = prices.length;
            document.getElementById('totalPrice').textContent = total;
            document.getElementById('quantity').value = prices.length;
            document.getElementById('total_price').value = total;
        }
    </script>

    <footer class="footer">
        <br>
        <img src="https://i.ibb.co/W49PVTYr/411-20250404174508.png" alt="Adventure Coast Logo">
        <p>Linggang guli guli guli wangja, ling ganggu, ling ganggu, TH</p>
        <br><br>
        <div class="social-icons">
            <a href="https://facebook.com" target="_blank"><i class="fa-brands fa-facebook-f"></i></a>
            <a href="https://tiktok.com" target="_blank"><i class="fa-brands fa-tiktok"></i></a>
            <a href="https://instagram.com" target="_blank"><i class="fa-brands fa-instagram"></i></a>
            <a href="mailto:someone@example.com"><i class="fa-solid fa-envelope"></i></a>
        </div>
        <br>
        <div class="links">
            <a href="#">FAQs</a>
            <a href="#">Careers</a>
            <a href="#">Contact Us</a>
            <a href="#">Terms & Conditions</a>
            <a href="#">Privacy Policy & Cookies</a>
        </div>
        <p class="copyright" style="color: yellow; font-weight: bold;">© 2025 DOKi BOOKi.</p>
    </footer>

    <div class="admin-wrapper">
        <div class="admin" id="adminButton">
            <input type="checkbox" id="adminCheckbox" hidden />
            <span></span>
            <span></span>
            <span></span>
            <span></span>
        </div>
        <div id="chat-box" class="chat-box">
            <div class="chat-header">
                <span>Admin</span>
            </div>
            <div class="chat-messages" id="chat-messages">
                <!-- ข้อความแชทจะมาที่นี่ -->
            </div>
            <input type="text" id="chat-input" class="chat-input" placeholder="text here!">
            <button id="send-message" class="send-message">send</button>
        </div>
    </div>
</body>

</html>