<?php
session_start();
if (!isset($_SESSION["user_username"])) {
    // ถ้ายังไม่ได้ล็อกอิน
    header("Location: login.php"); // เปลี่ยนไปหน้า login
    exit();
}

// เชื่อมต่อฐานข้อมูล
$conn = new mysqli("localhost", "root", "", "amusement_park");

// ตรวจสอบการเชื่อมต่อ
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ดึงข้อมูล username จาก session
$username = $_SESSION["user_username"];

// เช็คว่ามีรายการที่เลือกมาหรือไม่
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['selected_ids']) && is_array($_POST['selected_ids'])) {
    $selected_ids = $_POST['selected_ids'];

    if (isset($_POST['confirm_payment'])) {
        $selected_ids = $_POST['selected_ids'];
        $payer_name = $_POST['payer_name']; // <--- รับค่าที่ผู้ใช้กรอก
        $card_number = $_POST['card_number'];
        $payment_method = $_POST['payment_method'];
        $payment_status = 'paid';
        $paid_at = date('Y-m-d H:i:s');

        $username = $_SESSION['user_username']; 
        $total_amount = 0;

        // รวมยอดเงิน
        foreach ($selected_ids as $id) {
            $booking_stmt = $conn->prepare("SELECT * FROM bookings1 WHERE id = ?");
            $booking_stmt->bind_param("i", $id);
            $booking_stmt->execute();
            $booking_result = $booking_stmt->get_result();
            $booking = $booking_result->fetch_assoc();

            $ticket_stmt = $conn->prepare("SELECT price FROM tickets WHERE id = ?");
            $ticket_stmt->bind_param("i", $booking['ticket_id']);
            $ticket_stmt->execute();
            $ticket_result = $ticket_stmt->get_result();
            $ticket = $ticket_result->fetch_assoc();

            $total_amount += $ticket['price'] * $booking['quantity'];

            if (!$username) {
                $username = $_SESSION['user_username']; // หรือใช้ $_SESSION['username']
            }
        }

        // Insert ข้อมูล payment
        $insert_stmt = $conn->prepare("INSERT INTO payments (username, payer_name, card_number, payment_method, amount, payment_status, paid_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $insert_stmt->bind_param("sssssss", $username, $payer_name, $card_number, $payment_method, $total_amount, $payment_status, $paid_at);
        $insert_stmt->execute();

        $payment_id = $conn->insert_id;

        // อัปเดต bookings1
        foreach ($selected_ids as $id) {
            $update_stmt = $conn->prepare("UPDATE bookings1 SET payment_status = 'paid' WHERE id = ?");
            $update_stmt->bind_param("i", $id);
            $update_stmt->execute();
        }

        echo "<script>alert('Payments Success $payer_name'); window.location.href = 'profile.php';</script>";
        exit;
    }
} else {
    echo "<p>ไม่ได้เลือกรายการจองใด ๆ</p>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style1.css">
    <script src="script.js" defer></script>
    <title>Reservation</title>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@400;700&family=Henny+Penny&family=Pixelify+Sans:wght@400..700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <title>Payments</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 0;
        }

        .payment-form {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            max-width: 600px;
            margin: auto;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        h2 {
            text-align: center;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="number"],
        select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .button-pay {
            margin-top: 30px;
            background-color: #28a745;
            color: white;
            border: none;
            padding: 15px;
            width: 100%;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        .button-pay:hover {
            background-color: #218838;
        }
    </style>
</head>

<body>
    <header>
        <div class="logo">
            <img src="https://i.ibb.co/W49PVTYr/411-20250404174508.png" alt="Fun Spot">
        </div>
        <nav>
            <ul>
                <li><a href="reservation.php" class="button">Reservation</a></li>
                <li><a href="index.php" class="cc">Home</a></li>
                <li><a href="rides.php" class="cc">Rides</a></li>
                <li><a href="about.php" class="cc">About</a></li>
                <?php if (isset($_SESSION["user_id"])): ?>
                    <li class="dropdown">
                        <a href="#" class="cc" id="dropdown-btn" style="background-color:#FE654F;"><?= htmlspecialchars($_SESSION["user_username"]) ?></a>
                        <div class="dropdown-content">
                            <a href="profile.php">Profile</a>
                            <a href="logout.php">Logout</a>
                        </div>
                    </li>
                <?php else: ?>
                    <li><a href="login.php" class="cc">Login</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>
    <section class="farea">
        <div class="glass">
            <div class="payment-form">
                <h2 style="color:white; font-size: 70px; text-shadow: -1px -1px 0 black, 5px -1px 0 black, -1px 5px 0 black, 1px 1px 0 black; font-family: 'Pixelify Sans';">Payment Form</h2>
                <form method="post" action="payment.php">
                    <!-- ส่งค่า selected_ids กลับไปเพื่ออัปเดต -->
                    <?php foreach ($selected_ids as $id): ?>
                        <input type="hidden" name="selected_ids[]" value="<?= htmlspecialchars($id) ?>">
                    <?php endforeach; ?>
                    <input type="text" name="payer_name" id="payer_name" placeholder="Payer Name" required>
                    <input type="text" name="card_number" id="card_number" placeholder="Card Number" required>

                    <label for="payment_method" style="color: black;">Payment Method</label>
                    <select name="payment_method" id="payment_method" style="font-family: 'Pixelify Sans';" required>
                        <option value="">Select</option>
                        <option value="credit_card">credit card</option>
                        <option value="bank_transfer">bank transfer</option>
                        <option value="qr_code">QR Code</option>
                    </select>

                    <button type="submit" name="confirm_payment" class="button-pay">Comfirm Payment</button>
                </form>
            </div>
        </div>
    </section>
    <footer class="footer">
        <br>
        <img src="https://i.ibb.co/W49PVTYr/411-20250404174508.png" alt="Adventure Coast Logo">
        <p>Linggang guli guli guli wangja, ling ganggu, ling ganggu, TH</p>
        <br><br>
        <div class="social-icons">
            <a href="https://facebook.com" target="_blank"><i class="fa-brands fa-facebook-f"></i></a>
            <a href="https://tiktok.com" target="_blank"><i class="fa-brands fa-tiktok"></i></a>
            <a href="https://instagram.com" target="_blank"><i class="fa-brands fa-instagram"></i></a>
            <a href="mailto:someone@example.com"><i class="fa-solid fa-envelope"></i></a>
        </div>
        <br>
        <div class="links">
            <a href="#">FAQs</a>
            <a href="#">Careers</a>
            <a href="#">Contact Us</a>
            <a href="#">Terms & Conditions</a>
            <a href="#">Privacy Policy & Cookies</a>
        </div>
        <p class="copyright" style="color: yellow; font-weight: bold;">© 2025 DOKi BOOKi.</p>
    </footer>

    <div class="admin-wrapper">
        <div class="admin" id="adminButton">
            <input type="checkbox" id="adminCheckbox" hidden />
            <span></span>
            <span></span>
            <span></span>
            <span></span>
        </div>
        <div id="chat-box" class="chat-box">
            <div class="chat-header">
                <span>Admin</span>
            </div>
            <div class="chat-messages" id="chat-messages">
                <!-- ข้อความแชทจะมาที่นี่ -->
            </div>
            <input type="text" id="chat-input" class="chat-input" placeholder="text here!">
            <button id="send-message" class="send-message">send</button>
        </div>
    </div>
</body>

</html>