<?php
session_start();
if (!isset($_SESSION["user_username"])) {
    header("Location: login.php");
    exit();
}

// เชื่อมต่อฐานข้อมูล
$conn = new mysqli("localhost", "root", "", "amusement_park");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// รับค่า id จาก URL
if (isset($_GET['id'])) {
    $booking_id = $_GET['id'];

    // ดึงข้อมูลการจองจากฐานข้อมูล
    $sql = "SELECT * FROM bookings1 WHERE id = ? AND user_username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $booking_id, $_SESSION["user_username"]);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // ดึงชื่อประเภทตั๋ว
        $ticket_id = $row['ticket_id'];
        $ticket_sql = "SELECT ticket_type FROM tickets WHERE id = ?";
        $ticket_stmt = $conn->prepare($ticket_sql);
        $ticket_stmt->bind_param("i", $ticket_id);
        $ticket_stmt->execute();
        $ticket_result = $ticket_stmt->get_result();
        $ticket_row = $ticket_result->fetch_assoc();

        echo "<h2>รายละเอียดการจอง</h2>";
        echo "<p>ประเภทตั๋ว: " . $ticket_row['ticket_type'] . "</p>";
        echo "<p>วันที่จอง: " . $row['booking_date'] . "</p>";
        echo "<p>สถานะการจ่ายเงิน: " . $row['payment_status'] . "</p>";
        echo "<p>ชื่อผู้จอง: " . $row['firstname'] . " " . $row['lastname'] . "</p>";
        echo "<p>หมายเลขพาสปอร์ต: " . $row['passport_id'] . "</p>";
    } else {
        echo "<p>ไม่พบการจองที่คุณต้องการดู</p>";
    }
} else {
    echo "<p>ไม่พบการจองที่คุณต้องการดู</p>";
}

$conn->close();
?>
