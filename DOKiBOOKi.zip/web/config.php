<?php
$host = "sql106.infinityfree.com";
$db_username = "if0_38690293";
$db_password = "dokibooki123";
$db_name = "if0_38690293_amusement_park";

$conn = mysqli_connect($host, $db_username, $db_password, $db_name);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

mysqli_set_charset($conn, "utf8");

echo "เชื่อมต่อฐานข้อมูลสำเร็จ!";
?>