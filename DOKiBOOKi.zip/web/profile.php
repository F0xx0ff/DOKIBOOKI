<?php
session_start();
if (!isset($_SESSION["user_username"])) {
    // ถ้ายังไม่ได้ล็อกอิน
    header("Location: login.php"); // เปลี่ยนไปหน้า login
    exit();
}

// เชื่อมต่อฐานข้อมูล
$conn = new mysqli("localhost", "root", "", "amusement_park");

// ตรวจสอบการเชื่อมต่อ
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ดึงข้อมูล username จาก session
$username = $_SESSION["user_username"];

// ดึงข้อมูลการจองจากฐานข้อมูลที่มี username ตรงกับผู้ที่ล็อกอิน
$sql = "SELECT * FROM bookings1 WHERE user_username = ? ORDER BY booking_date DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style1.css">
    <script src="script.js" defer></script>
    <title>Reservation</title>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@400;700&family=Henny+Penny&family=Pixelify+Sans:wght@400..700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        .booking-container {
            display: flex;
            flex-direction: row;
            flex-wrap: wrap;
            gap: 20px;
            margin: 20px auto;
            justify-content: center;
            align-items: flex-start;
        }

        .booking-card {
            background-color: transparent;
            border: 2px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 300px;
            cursor: pointer;
            transition: 0.3s;
            position: relative;
        }

        .booking-card.selected {
            border: 2px solid #28a745;
            background-color: #e6ffee;
        }

        .booking-card.unselectable {
            opacity: 0.6;
            cursor: not-allowed;
            pointer-events: none;
        }

        .booking-info {
            flex: 1 1 200px;
            margin: 10px 0;
        }

        .booking-card input[type="checkbox"] {
            display: none;
        }

        .view-details {
            color: #FE654F;
            text-decoration: none;
            font-weight: bold;
        }

        .view-details:hover {
            text-decoration: underline;
        }

        .farea1 {
            background: linear-gradient(-45deg, rgb(242, 172, 162), rgb(123, 234, 129), rgb(233, 177, 238)d, rgb(99, 140, 235));
            background-size: 400% 400%;
            animation: gradient1 15s ease infinite;
            min-height: 400px;
            width: 100%;
            padding: auto;
            margin: 0;
            text-align: center;
        }

        @keyframes gradient1 {
            0% {
                background-position: 0% 50%;
            }

            50% {
                background-position: 100% 50%;
            }

            100% {
                background-position: 0% 50%;
            }
        }
    </style>
</head>

<body>
    <header>
        <div class="logo">
            <img src="https://i.ibb.co/W49PVTYr/411-20250404174508.png" alt="Fun Spot">
        </div>
        <nav>
            <ul>
                <li><a href="reservation.php" class="button">Reservation</a></li>
                <li><a href="index.php" class="cc">Home</a></li>
                <li><a href="rides.php" class="cc">Rides</a></li>
                <li><a href="about.php" class="cc">About</a></li>
                <?php if (isset($_SESSION["user_id"])): ?>
                    <li class="dropdown">
                        <a href="#" class="cc" id="dropdown-btn" style="background-color:#FE654F;"><?= htmlspecialchars($_SESSION["user_username"]) ?></a>
                        <div class="dropdown-content">
                            <a href="profile.php">Profile</a>
                            <a href="logout.php">Logout</a>
                        </div>
                    </li>
                <?php else: ?>
                    <li><a href="login.php" class="cc">Login</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>
    <section class="farea1">
        <h2 style="color:white; font-size: 70px; text-shadow: -1px -1px 0 black, 5px -1px 0 black, -1px 5px 0 black, 1px 1px 0 black; font-family: 'Pixelify Sans';">Reservation List</h2>

        <?php if ($result->num_rows > 0): ?>
            <form action="payment.php" method="POST" id="paymentForm">
                <div class="booking-container">
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <?php
                        $ticket_id = $row['ticket_id'];
                        $ticket_sql = "SELECT ticket_type, price  FROM tickets WHERE id = ?";
                        $ticket_stmt = $conn->prepare($ticket_sql);
                        $ticket_stmt->bind_param("i", $ticket_id);
                        $ticket_stmt->execute();
                        $ticket_result = $ticket_stmt->get_result();
                        $ticket_row = $ticket_result->fetch_assoc();
                        ?>
                        <label class="booking-card <?= $row['payment_status'] === 'paid' ? 'unselectable' : '' ?>">
                            <?php if ($row['payment_status'] !== 'paid'): ?>
                                <input type="checkbox" name="selected_ids[]" value="<?= $row['id'] ?>" hidden>
                            <?php endif; ?>
                            <div class="booking-info"><strong>📅 Date of Reservation:</strong> <?= htmlspecialchars($row['booking_date']) ?></div>
                            <div class="booking-info"><strong>🎟️ Ticket Type:</strong> <?= htmlspecialchars($ticket_row['ticket_type']) ?></div>
                            <div class="booking-info"><strong>💳 Payment Status:</strong> <?= htmlspecialchars($row['payment_status']) ?></div>
                            <?php if ($ticket_row): ?>
                                <div class="booking-info">
                                    <strong>💰 Price:</strong> <?= number_format($ticket_row['price'], 2) ?> $
                                </div>
                            <?php else: ?>
                                <div class="booking-info">Ticket not found</div>
                            <?php endif; ?>
                        </label>
                    <?php endwhile; ?>
                </div>
                <button class="comfirm" type="submit">
                    <div><span>Pays</span></div>
                </button>
            </form>
        <?php else: ?>
            <p>No List</p>
        <?php endif; ?>
    </section>
    <footer class="footer">
        <br>
        <img src="https://i.ibb.co/W49PVTYr/411-20250404174508.png" alt="Adventure Coast Logo">
        <p>Linggang guli guli guli wangja, ling ganggu, ling ganggu, TH</p>
        <br><br>
        <div class="social-icons">
            <a href="https://facebook.com" target="_blank"><i class="fa-brands fa-facebook-f"></i></a>
            <a href="https://tiktok.com" target="_blank"><i class="fa-brands fa-tiktok"></i></a>
            <a href="https://instagram.com" target="_blank"><i class="fa-brands fa-instagram"></i></a>
            <a href="mailto:someone@example.com"><i class="fa-solid fa-envelope"></i></a>
        </div>
        <br>
        <div class="links">
            <a href="#">FAQs</a>
            <a href="#">Careers</a>
            <a href="#">Contact Us</a>
            <a href="#">Terms & Conditions</a>
            <a href="#">Privacy Policy & Cookies</a>
        </div>
        <p class="copyright" style="color: yellow; font-weight: bold;">© 2025 DOKi BOOKi.</p>
    </footer>

    <div class="admin-wrapper">
        <div class="admin" id="adminButton">
            <input type="checkbox" id="adminCheckbox" hidden />
            <span></span>
            <span></span>
            <span></span>
            <span></span>
        </div>
        <div id="chat-box" class="chat-box">
            <div class="chat-header">
                <span>Admin</span>
            </div>
            <div class="chat-messages" id="chat-messages">
                <!-- ข้อความแชทจะมาที่นี่ -->
            </div>
            <input type="text" id="chat-input" class="chat-input" placeholder="text here!">
            <button id="send-message" class="send-message">send</button>
        </div>
    </div>
    <script>
        document.querySelectorAll('.booking-card').forEach(card => {
            card.addEventListener('click', (e) => {
                // ป้องกันคลิกที่ลิงก์ไม่ให้ toggle การเลือก
                if (e.target.tagName === 'A') return;

                const checkbox = card.querySelector('input[type="checkbox"]');
                checkbox.checked = !checkbox.checked;
                card.classList.toggle('selected', checkbox.checked);
            });
        });
    </script>
</body>

</html>

<?php
$conn->close();
?>