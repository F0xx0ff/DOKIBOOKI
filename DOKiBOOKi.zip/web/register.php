<?php
ob_start(); // ป้องกัน header error

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "amusement_park";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("การเชื่อมต่อล้มเหลว: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars(trim($_POST["name"]));
    $username = htmlspecialchars(trim($_POST["username"]));
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = password_hash($_POST["password"], PASSWORD_BCRYPT);

    // ตรวจสอบ username ซ้ำ
    $check_username = $conn->prepare("SELECT id FROM users1 WHERE username = ?");
    $check_username->bind_param("s", $username);
    $check_username->execute();
    $check_username->store_result();

    if ($check_username->num_rows > 0) {
        echo "❌ ชื่อผู้ใช้นี้ถูกใช้งานไปแล้ว!";
    } else {
        // ตรวจสอบ email ซ้ำ
        $check_email = $conn->prepare("SELECT id FROM users1 WHERE email = ?");
        $check_email->bind_param("s", $email);
        $check_email->execute();
        $check_email->store_result();

        if ($check_email->num_rows > 0) {
            echo "❌ อีเมลนี้ถูกใช้งานไปแล้ว!";
        } else {
            // เพิ่มข้อมูลผู้ใช้ใหม่
            $stmt = $conn->prepare("INSERT INTO users1 (name, username, email, password) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $name, $username, $email, $password);
            if ($stmt->execute()) {
                echo "✅ สมัครสมาชิกสำเร็จ! กำลังกลับไปยังหน้าเข้าสู่ระบบ...";
                echo '<script>
                    setTimeout(function() {
                        window.location.href = "login.php";
                    }, 2000);
                </script>';
                exit();
            } else {
                echo "❌ เกิดข้อผิดพลาด: " . $stmt->error;
            }
            $stmt->close();
        }
        $check_email->close();
    }
    $check_username->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script src="script.js" defer></script>
    <title>Registration</title>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@400;700&family=Henny+Penny&family=Pixelify+Sans:wght@400..700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>

<body>
    <header>
        <div class="logo">
            <img src="https://i.ibb.co/W49PVTYr/411-20250404174508.png" alt="Fun Spot">
        </div>
        <nav>
            <ul>
                <li><a href="reservation.php" class="button">Reservation</a></li>
                <li><a href="index.php" class="cc">Home</a></li>
                <li><a href="rides.php" class="cc">Rides</a></li>
                <li><a href="about.php" class="cc">About</a></li>
                <li><a href="login.php" class="cc" style="background-color: #FE654F;">Login</a></li>
            </ul>
        </nav>
    </header>

    <section class="farea">
        <div class="glass">
            <h2 style="font-size: 70px; text-shadow: -1px -1px 0 black, 5px -1px 0 black, -1px 5px 0 black, 1px 1px 0 black;">REGISTRATION</h2>
            <br>
            <form action="register.php" method="POST">
                <input type="text" id="name" name="name" placeholder="Name" required><br>
                <input type="email" id="email" name="email" placeholder="Email" required><br>
                <input type="username" id="username" name="username" placeholder="Username" required><br>
                <input type="password" id="password" name="password" placeholder="Password" required><br><br>

                <div class="bb" id="custom-submit">
                    <div class="bb1"><span>Register</span></div>
                </div>
                <input type="submit" id="real-submit" value="Go to DOKi BOOKi" style="display: none;">
            </form>
            <br>
            <p>Already had account?  <a href="login.php">Login</a></p>
        </div>
    </section>

    <footer class="footer">

        <br>
        <img src="https://i.ibb.co/W49PVTYr/411-20250404174508.png" alt="Adventure Coast Logo">

        <p>Linggang guli guli guli wangja, ling ganggu, ling ganggu, TH</p>

        <br><br>
        <div class="social-icons">
            <a href="https://facebook.com" target="_blank"><i class="fa-brands fa-facebook-f"></i></a>
            <a href="https://tiktok.com" target="_blank"><i class="fa-brands fa-tiktok"></i></a>
            <a href="https://instagram.com" target="_blank"><i class="fa-brands fa-instagram"></i></a>
            <a href="mailto:someone@example.com"><i class="fa-solid fa-envelope"></i></a>
        </div>
        <br>
        <div class="links">
            <a href="#">FAQs</a>
            <a href="#">Careers</a>
            <a href="#">Contact Us</a>
            <a href="#">Terms & Conditions</a>
            <a href="#">Privacy Policy & Cookies</a>
        </div>
        <p class="copyright" style="color: yellow; font-weight: bold;">© 2025 DOKi BOOKi.</p>
    </footer>

    <div class="admin-wrapper">
        <div class="admin" id="adminButton">
            <input type="checkbox" id="adminCheckbox" hidden />
            <span></span>
            <span></span>
            <span></span>
            <span></span>
        </div>

        <div id="chat-box" class="chat-box">
            <div class="chat-header">
                <span>Admin</span>
            </div>
            <div class="chat-messages" id="chat-messages">
                <!-- ข้อความแชทจะมาที่นี่ -->
            </div>
            <input type="text" id="chat-input" class="chat-input" placeholder="text here!">
            <button id="send-message" class="send-message">send</button>
        </div>
    </div>
</body>

</html>