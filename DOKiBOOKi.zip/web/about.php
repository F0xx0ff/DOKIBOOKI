<?php
session_start();
?>

<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DOKi BOOKi</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style1.css">
    <script src="script.js" defer></script>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@400;700&family=Henny+Penny&family=Pixelify+Sans:wght@400..700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        .map {
            width: 90%;
            text-align: center;
            margin: auto;
        }

        .map img {
            width: 100%;
            height: auto;
            border-radius: 10px;
        }
    </style>
</head>

<body>
    <header>
        <div class="logo">
            <img src="https://i.ibb.co/W49PVTYr/411-20250404174508.png" alt="Fun Spot">
        </div>
        <nav>
            <ul>
                <li><a href="reservation.php" class="button">Reservation</a></li>
                <li><a href="index.php" class="cc">Home</a></li>
                <li><a href="rides.php" class="cc">Rides</a></li>
                <li><a href="about.php" class="cc" style="background-color: #FE654F;">About</a></li>
                <?php if (isset($_SESSION["user_id"])): ?>
                    <li class="dropdown">
                        <a href="#" class="cc" id="dropdown-btn" style="background-color:rgb(224, 160, 254); color: black;"><?= htmlspecialchars($_SESSION["user_username"]) ?></a>
                        <div class="dropdown-content">
                            <a href="profile.php">Profile</a>
                            <a href="logout.php">Logout</a>
                        </div>
                    </li>
                <?php else: ?>
                    <li><a href="login.php" class="cc">Login</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>
    <section class="farea">
        <div class="glass">
            <h2 style="color:white; font-size: 90px; text-shadow: -1px -1px 0 black, 5px -1px 0 black, -1px 5px 0 black, 1px 1px 0 black; font-family: 'Pixelify Sans';">DOKi BOOKi</h2>
            <div class="map">
                <img src="https://printable-map.com/wp-content/uploads/2019/05/map-of-disney-world-hotels-and-theme-parks-disney-springsac2a2-area-with-printable-maps-of-disney-world-parks.jpg" alt="Carousel">
                <br><br>
                <h3 style="color: black;">MAP</h3>
            </div>
        </div>
    </section>
    <footer class="footer">
        <br>
        <img src="https://i.ibb.co/W49PVTYr/411-20250404174508.png" alt="Adventure Coast Logo">

        <p>Linggang guli guli guli wangja, ling ganggu, ling ganggu, TH</p>

        <br><br>
        <div class="social-icons">
            <a href="https://facebook.com" target="_blank"><i class="fa-brands fa-facebook-f"></i></a>
            <a href="https://tiktok.com" target="_blank"><i class="fa-brands fa-tiktok"></i></a>
            <a href="https://instagram.com" target="_blank"><i class="fa-brands fa-instagram"></i></a>
            <a href="mailto:someone@example.com"><i class="fa-solid fa-envelope"></i></a>
        </div>
        <br>
        <div class="links">
            <a href="#">FAQs</a>
            <a href="#">Careers</a>
            <a href="#">Contact Us</a>
            <a href="#">Terms & Conditions</a>
            <a href="#">Privacy Policy & Cookies</a>
        </div>
        <p class="copyright" style="color: yellow; font-weight: bold;">© 2025 DOKi BOOKi.</p>
    </footer>

    <div class="admin-wrapper">
        <div class="admin" id="adminButton">
            <input type="checkbox" id="adminCheckbox" hidden />
            <span></span>
            <span></span>
            <span></span>
            <span></span>
        </div>

        <div id="chat-box" class="chat-box">
            <div class="chat-header">
                <span>Admin</span>
            </div>
            <div class="chat-messages" id="chat-messages">
                <!-- ข้อความแชทจะมาที่นี่ -->
            </div>
            <input type="text" id="chat-input" class="chat-input" placeholder="text here!">
            <button id="send-message" class="send-message">send</button>
        </div>
    </div>

</body>

</html>