<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "amusement_park"; // เปลี่ยนเป็นชื่อฐานข้อมูลของคุณ

// สร้างการเชื่อมต่อ
$conn = new mysqli($servername, $username, $password, $dbname);

// ตรวจสอบการเชื่อมต่อ
if ($conn->connect_error) {
    die("❌ การเชื่อมต่อล้มเหลว: " . $conn->connect_error);
}

echo "✅ เชื่อมต่อฐานข้อมูลสำเร็จ!";
$conn->close();
?>
