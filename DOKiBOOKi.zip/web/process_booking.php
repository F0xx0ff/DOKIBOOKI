<?php
session_start();
ob_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "amusement_park";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("การเชื่อมต่อล้มเหลว: " . $conn->connect_error);
}

if (isset($_POST['username'])) {
    $username = $_POST['username'];
} else {
    // ถ้าไม่ส่งค่า username ให้ redirect หรือแสดง error
    die("Error: Username not provided.");
}

$booking_date = $_POST["booking_date"];
$firstname = $_POST["firstname"];
$lastname = $_POST["lastname"];
$passport_id = $_POST["passport_id"];
$timestamp = date('Y-m-d H:i:s');
$user = isset($_SESSION["user_username"]) ? $_SESSION["user_username"] : "guest";  // ใช้ชื่อผู้ใช้จาก session

$total_price = 0;

for ($i = 0; $i < count($firstname); $i++) {
    $ticket_key = "ticket_id_" . $i;
    $ticket_id = $_POST[$ticket_key];
    $quantity = 1;

    // ดึงราคาตั๋ว
    $price_stmt = $conn->prepare("SELECT price FROM tickets WHERE id = ?");
    $price_stmt->bind_param("i", $ticket_id);
    $price_stmt->execute();
    $result = $price_stmt->get_result();
    $price_row = $result->fetch_assoc();
    $price = $price_row['price'];
    $total_price += $price;
    $price_stmt->close();

    $passport = $i == 0 ? $passport_id : null;

    // เตรียม SQL statement สำหรับการบันทึกข้อมูลการจอง
    $stmt = $conn->prepare("INSERT INTO bookings1 (user_username, firstname, lastname, passport_id, ticket_id, booking_date, quantity, payment_status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?)");
    $stmt->bind_param("ssssisis", $user, $firstname[$i], $lastname[$i], $passport, $ticket_id, $booking_date, $quantity, $timestamp);
    $stmt->execute();
    $stmt->close();
}

$total_price = number_format($total_price, 2, '.', ',');

echo "✅ จองสำเร็จ! คุณจองทั้งหมด " . count($firstname) . " ใบ รวมเป็นเงิน $total_price บาท";
echo '<br><a href="reservation.php">กลับหน้าจอง</a>';

$conn->close();
?>
