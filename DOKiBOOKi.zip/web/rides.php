<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style1.css">
    <script src="script.js" defer></script>
    <title>Reservation</title>
    <link
        href="https://fonts.googleapis.com/css2?family=Bai+Jamjuree:wght@400;700&family=Henny+Penny&family=Pixelify+Sans:wght@400..700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
    <header>
        <div class="logo">
            <img src="https://i.ibb.co/W49PVTYr/411-20250404174508.png" alt="Fun Spot">
        </div>
        <nav>
            <ul>
                <li><a href="reservation.php" class="button">Reservation</a></li>
                <li><a href="index.php" class="cc">Home</a></li>
                <li><a href="rides.php" class="cc" style="background-color:#FE654F;">Rides</a></li>
                <li><a href="about.php" class="cc">About</a></li>
                <?php if (isset($_SESSION["user_id"])): ?>
                    <li class="dropdown">
                        <a href="#" class="cc" id="dropdown-btn" style="background-color: rgb(224, 160, 254);"><?= htmlspecialchars($_SESSION["user_username"]) ?></a>
                        <div class="dropdown-content">
                            <a href="profile.php">Profile</a>
                            <a href="logout.php">Logout</a>
                        </div>
                    </li>
                <?php else: ?>
                    <li><a href="login.php" class="cc">Login</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>
    <section class="farea">
        <div class="or">DOKi BOOKi's Rides</div>
        <br>
        <br>
        <div class="ride-cards">
            <div class="ride-card">
                <img src="https://wallup.net/wp-content/uploads/2019/09/663393-roller-coaster-amusement-park-fun-rides-1roll-adventure-summer-people.jpg" alt="Roller Coaster">
                <br><br>
                <h3>Roller Coaster</h3>
            </div>


            <div class="ride-card">
                <img src="https://d2rhr99xjw3azl.cloudfront.net/app/uploads/2025/01/Twister-9-2.jpg" alt="Ferris Wheel">
                <h3>Twister</h3>
            </div>


            <div class="ride-card">
                <img src="https://watermark.lovepik.com/photo/20211126/large/lovepik-beautiful-merry-go-round-picture_501084003.jpg" alt="Carousel">
                <br><br>
                <h3>Carousel</h3>
            </div>
            
        </div>
    </section>
    <footer class="footer">
        <br>
        <img src="https://i.ibb.co/W49PVTYr/411-20250404174508.png" alt="Adventure Coast Logo">
        <p>Linggang guli guli guli wangja, ling ganggu, ling ganggu, TH</p>
        <br><br>
        <div class="social-icons">
            <a href="https://facebook.com" target="_blank"><i class="fa-brands fa-facebook-f"></i></a>
            <a href="https://tiktok.com" target="_blank"><i class="fa-brands fa-tiktok"></i></a>
            <a href="https://instagram.com" target="_blank"><i class="fa-brands fa-instagram"></i></a>
            <a href="mailto:someone@example.com"><i class="fa-solid fa-envelope"></i></a>
        </div>
        <br>
        <div class="links">
            <a href="#">FAQs</a>
            <a href="#">Careers</a>
            <a href="#">Contact Us</a>
            <a href="#">Terms & Conditions</a>
            <a href="#">Privacy Policy & Cookies</a>
        </div>
        <p class="copyright" style="color: yellow; font-weight: bold;">© 2025 DOKi BOOKi.</p>
    </footer>

    <div class="admin-wrapper">
        <div class="admin" id="adminButton">
            <input type="checkbox" id="adminCheckbox" hidden />
            <span></span>
            <span></span>
            <span></span>
            <span></span>
        </div>
        <div id="chat-box" class="chat-box">
            <div class="chat-header">
                <span>Admin</span>
            </div>
            <div class="chat-messages" id="chat-messages">
                <!-- ข้อความแชทจะมาที่นี่ -->
            </div>
            <input type="text" id="chat-input" class="chat-input" placeholder="text here!">
            <button id="send-message" class="send-message">send</button>
        </div>
    </div>
</body>
</html>